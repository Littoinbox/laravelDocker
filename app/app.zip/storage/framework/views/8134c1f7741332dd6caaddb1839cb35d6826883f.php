<?php $__env->startSection('content'); ?>
    <div class="container">
        <test-component :urldata="<?php echo e(json_encode($url_data)); ?>"></test-component>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/test.blade.php ENDPATH**/ ?>